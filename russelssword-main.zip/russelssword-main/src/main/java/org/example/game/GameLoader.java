package org.example.game;

import org.example.database.UserProgressDAO;
import org.example.database.AbilityDAO;
import org.example.database.EnemyDAO;
import org.example.database.ZoneDAO;
import org.example.combat.character;
import org.example.combat.enemy;
import org.example.database.ZoneData;
import org.example.database.ZoneData;

import java.sql.SQLException;
import java.util.Map;
import java.util.HashMap;

public class GameLoader {

    public void loadGame(GameState state) {

        // Load zone metadata from local DB
        state.zoneData = ZoneDAO.getZone(state.currentZone);

        // Load enemy for this zone
        state.currentEnemy = EnemyDAO.getEnemyByZone(state.currentZone);

        // Load abilities from local DB
        Map<String, Integer> abilities = new HashMap<>();
        try {
            abilities = AbilityDAO.getAbilities(state.userId);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        // Create Russel with saved stats
        state.russel = new character(
                "Russel",
                state.hp,
                state.level,
                abilities
        );
    }
}