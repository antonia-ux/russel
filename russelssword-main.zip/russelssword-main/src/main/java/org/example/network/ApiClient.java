package org.example.network;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import io.vertx.core.json.JsonObject;

public class ApiClient {
    private static final String BASE_URL = "http://localhost:8080";

    public static JsonObject loadProgress(String jwtToken) throws Exception {
        HttpClient client = HttpClient.newHttpClient();

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(BASE_URL + "/game/load"))
                .header("Authorization", "Bearer " + jwtToken)
                .GET()
                .build();

        HttpResponse<String> response =
                client.send(request, HttpResponse.BodyHandlers.ofString());

        return new JsonObject(response.body());
    }

    public static String login(String email, String password) throws Exception {
        HttpClient client = HttpClient.newHttpClient();

        String form = "email=" + email + "&password=" + password;

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(BASE_URL + "/login"))
                .header("Content-Type", "application/x-www-form-urlencoded")
                .POST(HttpRequest.BodyPublishers.ofString(form))
                .build();

        HttpResponse<String> response =
                client.send(request, HttpResponse.BodyHandlers.ofString());

        // 🔍 DEBUG PRINTS — ALWAYS PRINTS, NO MATTER WHAT
        System.out.println("STATUS CODE: " + response.statusCode());
        System.out.println("RESPONSE BODY: " + response.body());

        if (response.statusCode() == 200) {
            return response.body(); // raw token OR JSON, we will see
        } else {
            throw new Exception("Login failed");
        }
    }

    public static void register(String email, String password) throws Exception {
        HttpClient client = HttpClient.newHttpClient();

        String form = "email=" + email + "&password=" + password;

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(BASE_URL + "/register"))
                .header("Content-Type", "application/x-www-form-urlencoded")
                .POST(HttpRequest.BodyPublishers.ofString(form))
                .build();

        client.send(request, HttpResponse.BodyHandlers.ofString());
    }
    public static void saveProgress(String jwtToken, int zone, int hp, int level) throws Exception {
        HttpClient client = HttpClient.newHttpClient();

        JsonObject body = new JsonObject()
                .put("current_zone_id", zone)
                .put("hp", hp)
                .put("level", level);

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(BASE_URL + "/game/save"))
                .header("Authorization", "Bearer " + jwtToken)
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(body.encode()))
                .build();

        HttpResponse<String> response =
                client.send(request, HttpResponse.BodyHandlers.ofString());

        System.out.println("SAVE STATUS: " + response.statusCode());
        System.out.println("SAVE RESPONSE: " + response.body());

        if (response.statusCode() != 200) {
            throw new Exception("Failed to save progress");
        }
    }
}