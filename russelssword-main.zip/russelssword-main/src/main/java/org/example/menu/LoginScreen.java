package org.example.menu;

import org.example.network.ApiClient;

import javax.swing.*;
import java.awt.*;

public class LoginScreen extends JFrame {

    private JTextField emailField;
    private JPasswordField passwordField;
    private JButton loginBtn;
    private JButton registerBtn;

    public LoginScreen() {
        setTitle("Login");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new GridBagLayout());
        panel.setBackground(new Color(30, 30, 30));
        setContentPane(panel);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel emailLabel = new JLabel("Email:");
        emailLabel.setForeground(Color.WHITE);
        gbc.gridx = 0; gbc.gridy = 0;
        panel.add(emailLabel, gbc);

        emailField = new JTextField();
        gbc.gridx = 1; gbc.gridy = 0;
        panel.add(emailField, gbc);

        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setForeground(Color.WHITE);
        gbc.gridx = 0; gbc.gridy = 1;
        panel.add(passwordLabel, gbc);

        passwordField = new JPasswordField();
        gbc.gridx = 1; gbc.gridy = 1;
        panel.add(passwordField, gbc);

        loginBtn = new JButton("Login");
        gbc.gridx = 0; gbc.gridy = 2;
        panel.add(loginBtn, gbc);

        registerBtn = new JButton("Register");
        gbc.gridx = 1; gbc.gridy = 2;
        panel.add(registerBtn, gbc);

        JLabel statusLabel = new JLabel("");
        statusLabel.setForeground(Color.RED);
        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2;
        panel.add(statusLabel, gbc);

        // -------------------------
        // LOGIN BUTTON ACTION
        // -------------------------
        loginBtn.addActionListener(e -> {
            String email = emailField.getText();
            String password = new String(passwordField.getPassword());

            if (email.isEmpty() || password.isEmpty()) {
                statusLabel.setText("Please enter email and password");
                return;
            }

            new Thread(() -> {
                try {
                    // ApiClient returns a RAW TOKEN STRING
                    String token = ApiClient.login(email, password);

                    SwingUtilities.invokeLater(() -> {
                        statusLabel.setText("Login successful");
                        new menu(email, token);  // open menu
                        dispose();               // close login screen
                    });

                } catch (Exception ex) {
                    SwingUtilities.invokeLater(() ->
                            statusLabel.setText("Invalid credentials")
                    );
                }
            }).start();
        });

        // -------------------------
        // REGISTER BUTTON ACTION
        // -------------------------
        registerBtn.addActionListener(e -> {
            String email = emailField.getText();
            String password = new String(passwordField.getPassword());

            if (email.isEmpty() || password.isEmpty()) {
                statusLabel.setText("Please enter email and password");
                return;
            }

            new Thread(() -> {
                try {
                    ApiClient.register(email, password);

                    SwingUtilities.invokeLater(() ->
                            statusLabel.setText("Registered successfully")
                    );

                } catch (Exception ex) {
                    SwingUtilities.invokeLater(() ->
                            statusLabel.setText("Registration failed")
                    );
                }
            }).start();
        });

        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(LoginScreen::new);
    }
}