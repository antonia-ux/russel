package org.example.menu;

import org.example.visuals.Background;
import javax.swing.*;
import java.awt.*;
import org.example.game.GameState;
import org.example.combat.character;
import org.example.network.ApiClient;
import io.vertx.core.json.JsonObject;

public class menu extends JFrame {

    private final String email;
    private final String jwtToken;

    // Shared game state for this user session
    private GameState state = new GameState();

    public menu(String email, String jwtToken) {
        this.email = email;
        this.jwtToken = jwtToken;

        setTitle("Russel's Sword");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(960, 540);
        setResizable(false);

        JPanel background = new JPanel() {
            private Image img = new ImageIcon(getClass().getResource("/images/menu.png")).getImage();

            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.drawImage(img, 0, 0, 960, 540, this);
            }
        };
        background.setLayout(new GridBagLayout());
        setContentPane(background);

        JPanel buttonPanel = new JPanel();
        buttonPanel.setOpaque(false);
        buttonPanel.setLayout(new GridLayout(4, 1, 10, 10)); // now 4 buttons

        JButton newGameBtn = createMenuButton("New Game");
        JButton continueBtn = createMenuButton("Continue");
        JButton saveBtn = createMenuButton("Save Game");
        JButton exitBtn = createMenuButton("Exit");

        buttonPanel.add(newGameBtn);
        buttonPanel.add(continueBtn);
        buttonPanel.add(saveBtn);
        buttonPanel.add(exitBtn);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(150, 0, 0, 0);
        background.add(buttonPanel, gbc);

        setLocationRelativeTo(null);
        setVisible(true);

        // -------------------------
        // DISABLE CONTINUE IF NO PROGRESS
        // -------------------------
        new Thread(() -> {
            try {
                JsonObject progress = ApiClient.loadProgress(jwtToken);
                SwingUtilities.invokeLater(() -> continueBtn.setEnabled(!progress.isEmpty()));
            } catch (Exception e) {
                SwingUtilities.invokeLater(() -> continueBtn.setEnabled(false));
            }
        }).start();

        // -------------------------
        // EXIT BUTTON
        // -------------------------
        exitBtn.addActionListener(e -> System.exit(0));

        // -------------------------
        // NEW GAME BUTTON
        // -------------------------
        newGameBtn.addActionListener(e -> {
            SwingUtilities.invokeLater(() -> {

                // Initialize new game state
                state.currentZone = 1;
                state.hp = 100;
                state.level = 1;
                state.russel = new character();

                JFrame gameFrame = new JFrame("Russel's Adventure");
                gameFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

                Background bg = new Background();
                gameFrame.add(bg);
                gameFrame.pack();
                gameFrame.setResizable(false);
                gameFrame.setLocationRelativeTo(null);

                // PAUSE MENU (ESC)
                addPauseMenu(gameFrame);

                // SAVE PROGRESS ON EXIT
                gameFrame.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        new Thread(() -> {
                            try {
                                ApiClient.saveProgress(jwtToken, state.currentZone, state.hp, state.level);
                                System.out.println("Progress saved on exit");
                            } catch (Exception ex) {
                                ex.printStackTrace();
                            }
                        }).start();
                    }
                });

                gameFrame.setVisible(true);
                dispose();
            });
        });

        // -------------------------
        // CONTINUE BUTTON
        // -------------------------
        continueBtn.addActionListener(e -> {
            new Thread(() -> {
                try {
                    JsonObject progress = ApiClient.loadProgress(jwtToken);

                    if (progress.isEmpty()) {
                        SwingUtilities.invokeLater(() ->
                                JOptionPane.showMessageDialog(this, "No saved progress found!")
                        );
                        return;
                    }

                    // Load into shared state
                    state.currentZone = progress.getInteger("current_zone_id");
                    state.hp = progress.getInteger("hp");
                    state.level = progress.getInteger("level");
                    state.russel = new character();

                    SwingUtilities.invokeLater(() -> {
                        JOptionPane.showMessageDialog(
                                this,
                                "Loaded progress:\n" +
                                        "Zone: " + state.currentZone + "\n" +
                                        "HP: " + state.hp + "\n" +
                                        "Level: " + state.level,
                                "Continue Game",
                                JOptionPane.INFORMATION_MESSAGE
                        );

                        JFrame gameFrame = new JFrame("Russel's Adventure");
                        gameFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

                        Background bg = new Background();
                        gameFrame.add(bg);

                        gameFrame.pack();
                        gameFrame.setResizable(false);
                        gameFrame.setLocationRelativeTo(null);

                        // PAUSE MENU (ESC)
                        addPauseMenu(gameFrame);

                        // SAVE PROGRESS ON EXIT
                        gameFrame.addWindowListener(new java.awt.event.WindowAdapter() {
                            @Override
                            public void windowClosing(java.awt.event.WindowEvent e) {
                                new Thread(() -> {
                                    try {
                                        ApiClient.saveProgress(jwtToken, state.currentZone, state.hp, state.level);
                                        System.out.println("Progress saved on exit");
                                    } catch (Exception ex) {
                                        ex.printStackTrace();
                                    }
                                }).start();
                            }
                        });

                        gameFrame.setVisible(true);
                        dispose();
                    });

                } catch (Exception ex) {
                    ex.printStackTrace();
                    SwingUtilities.invokeLater(() ->
                            JOptionPane.showMessageDialog(this, "Failed to load progress!")
                    );
                }
            }).start();
        });

        // -------------------------
        // SAVE GAME BUTTON
        // -------------------------
        saveBtn.addActionListener(e -> {
            new Thread(() -> {
                try {
                    ApiClient.saveProgress(jwtToken, state.currentZone, state.hp, state.level);

                    SwingUtilities.invokeLater(() ->
                            JOptionPane.showMessageDialog(this, "Progress saved!")
                    );

                } catch (Exception ex) {
                    ex.printStackTrace();
                    SwingUtilities.invokeLater(() ->
                            JOptionPane.showMessageDialog(this, "Failed to save progress!")
                    );
                }
            }).start();
        });
    }

    // -------------------------
    // PAUSE MENU FUNCTION
    // -------------------------
    private void addPauseMenu(JFrame gameFrame) {
        gameFrame.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyPressed(java.awt.event.KeyEvent e) {
                if (e.getKeyCode() == java.awt.event.KeyEvent.VK_ESCAPE) {

                    String[] options = {"Resume", "Save Game", "Exit"};
                    int choice = JOptionPane.showOptionDialog(
                            gameFrame,
                            "Paused",
                            "Pause Menu",
                            JOptionPane.DEFAULT_OPTION,
                            JOptionPane.PLAIN_MESSAGE,
                            null,
                            options,
                            options[0]
                    );

                    if (choice == 1) {
                        new Thread(() -> {
                            try {
                                ApiClient.saveProgress(jwtToken, state.currentZone, state.hp, state.level);
                            } catch (Exception ex) {
                                ex.printStackTrace();
                            }
                        }).start();
                    }
                    else if (choice == 2) {
                        new Thread(() -> {
                            try {
                                ApiClient.saveProgress(jwtToken, state.currentZone, state.hp, state.level);
                            } catch (Exception ex) {
                                ex.printStackTrace();
                            }
                        }).start();
                        System.exit(0);
                    }
                }
            }
        });
    }

    private JButton createMenuButton(String text) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Monospaced", Font.BOLD, 22));
        btn.setFocusPainted(false);

        Color baseBG = new Color(21, 41, 64);
        Color hoverBG = new Color(31, 61, 94);
        Color borderColor = new Color(179, 179, 24);

        btn.setForeground(borderColor);
        btn.setBackground(baseBG);

        btn.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(borderColor, 4),
                        BorderFactory.createEmptyBorder(10, 20, 10, 20)
                )
        );

        btn.setOpaque(true);
        btn.setContentAreaFilled(true);
        btn.setRolloverEnabled(false);
        btn.setFocusPainted(false);

        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseEntered(java.awt.event.MouseEvent e) {
                btn.setBackground(hoverBG);
            }

            @Override
            public void mouseExited(java.awt.event.MouseEvent e) {
                btn.setBackground(baseBG);
            }

            @Override
            public void mousePressed(java.awt.event.MouseEvent e) {
                btn.setBackground(hoverBG);
            }

            @Override
            public void mouseReleased(java.awt.event.MouseEvent e) {
                btn.setBackground(baseBG);
            }
        });

        return btn;
    }
}