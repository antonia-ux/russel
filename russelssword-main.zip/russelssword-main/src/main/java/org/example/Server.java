package org.example;

import io.vertx.core.Vertx;
import io.vertx.core.json.JsonArray;
import io.vertx.core.json.JsonObject;
import io.vertx.ext.auth.JWTOptions;
import io.vertx.ext.web.Router;
import io.vertx.ext.web.handler.BodyHandler;
import io.vertx.ext.web.handler.JWTAuthHandler;
import io.vertx.ext.auth.jwt.JWTAuth;
import io.vertx.ext.auth.jwt.JWTAuthOptions;
import io.vertx.ext.auth.PubSecKeyOptions;

import io.vertx.ext.jdbc.JDBCClient;
import org.mindrot.jbcrypt.BCrypt;

public class Server {

    public static void main(String[] args) {

        Vertx vertx = Vertx.vertx();


        JsonObject config = new JsonObject()
                .put("url", "jdbc:sqlite:src/main/resources/database/game.db")
                .put("driver_class", "org.sqlite.JDBC")
                .put("max_pool_size", 30);

        JDBCClient jdbc = JDBCClient.createShared(vertx, config);

        // -------------------------
        // JWT setup (HS256)
        // -------------------------
        JWTAuth jwt = JWTAuth.create(vertx, new JWTAuthOptions()
                .addPubSecKey(new PubSecKeyOptions()
                        .setAlgorithm("HS256")
                        .setBuffer("super-secret-key")
                        .setSymmetric(true)
                )
        );

        Router router = Router.router(vertx);
        router.route().handler(BodyHandler.create());

        // -------------------------
        // REGISTER (bcrypt)
        // -------------------------
        router.post("/register").handler(ctx -> {
            String email = ctx.request().getParam("email");
            String password = ctx.request().getParam("password");

            if (email == null || password == null) {
                ctx.response().setStatusCode(400).end("Missing email or password");
                return;
            }

            String hashed = BCrypt.hashpw(password, BCrypt.gensalt());

            String sql = "INSERT INTO UserAccount (email, password_hash) VALUES (?, ?)";

            jdbc.updateWithParams(sql, new JsonArray().add(email).add(hashed), res -> {
                if (res.succeeded()) {
                    ctx.response().end("User registered: " + email);
                } else {
                    res.cause().printStackTrace();
                    ctx.response().setStatusCode(500).end("Registration failed");
                }
            });
        });

        // -------------------------
        // LOGIN (bcrypt + JWT)
        // -------------------------
        router.post("/login").handler(ctx -> {
            String email = ctx.request().getParam("email");
            String password = ctx.request().getParam("password");

            if (email == null || password == null) {
                ctx.response().setStatusCode(400).end("Missing email or password");
                return;
            }

            String sql = "SELECT password_hash FROM UserAccount WHERE email = ?";

            jdbc.queryWithParams(sql, new JsonArray().add(email), res -> {
                if (res.succeeded() && !res.result().getRows().isEmpty()) {

                    String storedHash = res.result().getRows().get(0).getString("password_hash");

                    if (BCrypt.checkpw(password, storedHash)) {

                        String token = jwt.generateToken(
                                new JsonObject().put("email", email),
                                new JWTOptions().setExpiresInMinutes(60)
                        );

                        ctx.response().end(token);
                    } else {
                        ctx.response().setStatusCode(401).end("Invalid credentials");
                    }

                } else {
                    ctx.response().setStatusCode(401).end("Invalid credentials");
                }
            });
        });

        // -------------------------
        // PROTECTED ROUTES
        // -------------------------
        router.route("/game/*").handler(JWTAuthHandler.create(jwt));

        // PROFILE
        router.get("/game/profile").handler(ctx -> {
            try {
                if (ctx.user() == null) {
                    ctx.response().setStatusCode(401).end("Not authenticated");
                    return;
                }

                JsonObject principal = ctx.user().principal();
                if (principal == null || principal.getString("email") == null) {
                    ctx.response().setStatusCode(400).end("Invalid token");
                    return;
                }

                String email = principal.getString("email");
                System.out.println("Authenticated user: " + email);
                ctx.response().end("Welcome, " + email);

            } catch (Exception e) {
                e.printStackTrace();
                ctx.response().setStatusCode(500).end("Internal error: " + e.getMessage());
            }
        });

        // SAVE PROGRESS
        router.post("/game/save").handler(ctx -> {
            try {
                if (ctx.user() == null) {
                    ctx.response().setStatusCode(401).end("Not authenticated");
                    return;
                }

                String email = ctx.user().principal().getString("email");
                JsonObject body = ctx.getBodyAsJson();

                if (body == null) {
                    ctx.response().setStatusCode(400).end("Missing JSON body");
                    return;
                }

                String sql = "REPLACE INTO UserProgress (user_id, current_zone_id, hp, level) VALUES (?, ?, ?, ?)";

                jdbc.updateWithParams(sql, new JsonArray()
                                .add(email)
                                .add(body.getInteger("current_zone_id"))
                                .add(body.getInteger("hp"))
                                .add(body.getInteger("level")),
                        res -> {
                            if (res.succeeded()) {
                                ctx.response().end("Progress saved");
                            } else {
                                res.cause().printStackTrace();
                                ctx.response().setStatusCode(500).end("Failed to save progress");
                            }
                        });

            } catch (Exception e) {
                e.printStackTrace();
                ctx.response().setStatusCode(500).end("Internal error");
            }
        });

        // LOAD PROGRESS
        router.get("/game/load").handler(ctx -> {
            try {
                if (ctx.user() == null) {
                    ctx.response().setStatusCode(401).end("Not authenticated");
                    return;
                }

                String email = ctx.user().principal().getString("email");

                String sql = "SELECT current_zone_id, hp, level FROM UserProgress WHERE user_id = ?";

                jdbc.queryWithParams(sql, new JsonArray().add(email), res -> {
                    if (res.succeeded() && !res.result().getRows().isEmpty()) {
                        ctx.response().end(res.result().getRows().get(0).encode());
                    } else {
                        ctx.response().end("{}"); // no progress yet
                    }
                });

            } catch (Exception e) {
                e.printStackTrace();
                ctx.response().setStatusCode(500).end("Internal error");
            }
        });

        // -------------------------
        // START SERVER
        // -------------------------
        vertx.createHttpServer()
                .requestHandler(router)
                .listen(8080, http -> {
                    if (http.succeeded()) {
                        System.out.println("Server running on http://localhost:8080");
                    } else {
                        http.cause().printStackTrace();
                    }
                });
    }
}